<?php

// use Page;
// use SilverStripe\FullTextSearch\Solr\SolrIndex;

// class MyIndex extends SolrIndex
// {
//     public function init()
//     {
//         $this->addClass(Page::class);
//         $this->addClass(Member::class);
//         $this->addFulltextField('Title');
//        $this->addFulltextField('Content'); // only applies to Page class
//         $this->addFulltextField('FirstName'); // only applies to Member class
//     }
// }
