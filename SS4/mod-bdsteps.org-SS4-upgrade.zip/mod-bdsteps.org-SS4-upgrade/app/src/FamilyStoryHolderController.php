<?php

namespace BdSteps\Home;

use PageController;    

class FamilyStoryHolder_Controller extends PageController 
{

}

?>