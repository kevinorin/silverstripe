<?php

namespace BdSteps\Home;

use PageController;    

class HomePageController extends PageController 
{

}

?>