<?php

namespace BdSteps\Home;

use PageController;    

class FamilyStoryPage_Controller extends PageController 
{

}

?>