<?php

use SilverStripe\Control\Controller;
use SilverStripe\Control\HTTPRequest;

class StaffPage_Controller extends PageController 
{


}